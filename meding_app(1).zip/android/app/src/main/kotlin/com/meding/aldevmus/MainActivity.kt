package com.meding.aldevmus

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
